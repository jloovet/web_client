import React from "react"

class Recipe extends React.Component {

    render() {
      return (
  
        <li>{this.props.name}
          <ul>
            <li className="recipeDetails" >
              <textarea rows="3" cols="45" readOnly={true} defaultValue={this.props.details}></textarea>
            </li>
          </ul>
        </li>
      )
    }
  }
  
  

export default Recipe