
    import React from "react"

    class QuoteFetcher extends React.Component {
        state = {
          btnText: "Add a famous Qoute :)"
        }
  
        //Note: limited to 500 calls / month (see https://rapidapi.com/apidojo/api/tasty/)
        //create new key before handing in ovn 6!
        options = {
          method: 'POST',
          headers: {
            'content-type': 'application/json',
            'X-RapidAPI-Key': 'a97a27dba4msh0406c51ffc2c3b6p1e955djsnfc510facd835',
            'X-RapidAPI-Host': 'quotel-quotes.p.rapidapi.com'
          },
          body: '{}'
        };
  
        fetchQuote = () => {
          fetch('https://quotel-quotes.p.rapidapi.com/quotes/random', this.options)
            .then(response => response.json())
            .then(response => this.setStateFromResponse(response))
            .catch(err => console.error(err));
        };
  
        setStateFromResponse = (responseAsJSON) => {
          this.props.addQuoteProps(responseAsJSON.quote, responseAsJSON.name)
          //finaly, change text on buttons
          this.setState({
            btnText: "Replace the famous Qoute :)"
          })
        };
  
        render() {
          return (
            <button title="Adds a random quote to the grocery list" onClick={this.fetchQuote} className="btn-base"> {this.state.btnText} </button>
          )
        }
      }

      export default QuoteFetcher
  