import React from "react"


class GroceryInList extends React.Component {

    state = {
      editing: false,
      btnText: ""
  
    }
  
    handleEditing = () => {
      if (this.state.editing) {
        this.setState({
          editing: false,
          btnText: ""
        })
      } else {
        this.setState({
          editing: true,
          btnText: "Save"
        })
      }
    }
  
    handleUpdatedDone = event => {
      //console.log(event.key)
      if (event.key === "Enter") {
        this.setState({ editing: false, btnText: "" })
      }
    }
  
    render() {
      const completedStyle = {
        fontStyle: "italic",
        color: "#595959",
        opacity: 0.4,
        textDecoration: "line-through",
      }
  
      //"destructure" the item and get variables from it
      const { quantity, id, item, comment } = this.props.item
  
  
      //hantera edit-fältet
      let viewMode = {}
      let editMode = {}
      if (this.state.editing) {
        viewMode.display = "none"
      } else {
        editMode.display = "none"
      }
  
  
      return (
        <tr>
          <td className="item">
            <div style={viewMode}>
              <span style={false ? completedStyle : null}>
                {item}
              </span>
            </div>
            <input
              type="text"
              style={editMode}
              className="textInput"
              value={item}
              onChange={e => {
                this.props.setUpdate(e.target.value, id)
              }}
              onKeyDown={this.handleUpdatedDone}
            />
          </td>
          <td>
            <div style={viewMode}>
              <span style={false ? completedStyle : null}>
                {quantity}
              </span>
            </div>
  
            <select style={editMode}
              className="textInput"
              value={quantity}
              onChange={e => {
                this.props.setUpdateQnt(e.target.value, id)
              }}>
              <option value="1">1</option>
              <option value="2">2</option>
              <option value="3">3</option>
              <option value="4">4</option>
              <option value="5">5</option>
              <option value="6">6</option>
              <option value="7">7</option>
              <option value="8">8</option>
              <option value="9">9</option>
              <option value="10">10</option>
            </select>
  
          </td>
          <td>
            <div style={viewMode}>
              <span style={false ? completedStyle : null}>
                {comment}
              </span>
            </div>
  
            <input
              type="text"
              style={editMode}
              className="textInput"
              value={comment}
              onChange={e => {
                this.props.setUpdatedComment(e.target.value, id)
              }}
              onKeyDown={this.handleUpdatedDone}
            />
  
          </td>
          {!this.props.usedInPrintView &&
            <td className="button-col">
              <button title="Make changes to the item" style={{ fontWeight: this.state.editing ? "bold" : "normal" }} onClick={this.handleEditing}
                className="changebutton"> {this.state.btnText} <i className="fa fa-edit"></i></button>
              <button title="Delete the item" onClick={() => this.props.deleteItemProps(id)} className="delbutton" > <i className="fa fa-trash"></i> </button>
            </td>
          }
        </tr>
      )
    }
  }
  

export default GroceryInList