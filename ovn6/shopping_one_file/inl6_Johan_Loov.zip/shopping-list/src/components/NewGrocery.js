import React from "react"

class NewGrocery extends React.Component {
    state = {
      item: "",
      quantity: "",
      comment: ""
    };
  
  
    //could handle many fields, due to the name="item" extension below
    onChange = e => {
      this.setState({
        [e.target.name]: e.target.value,
      })
    }
  
    handleSubmit = e => {
      e.preventDefault()
      if (this.state.item.trim() === "") {
        alert("Must have a name")
        return
      }
      if (this.state.quantity === "" || this.state.quantity === "Nada") {
        alert("Must have a quantity")
        return
      }
      this.props.addItemProps(this.state.item, this.state.quantity, this.state.comment)
  
      //cleara state
      this.setState({
        item: "",
        comment: ""
      })
    }
  
  
  
    render() {
      return (
        <form onSubmit={this.handleSubmit} className="form-container" >
          <fieldset>
            <legend>Add new Grocery Item:</legend>
            <input
              title="Add Item Name here"
              placeholder="Item Name"
              type="text"
              className="form-input"
              value={this.state.item}
              name="item"
              onChange={this.onChange}
            />
  
  
            <select onChange={this.onChange} id="quantities" name="quantity" required title="Add number of tems here" placeholder="quantity" className="form-input">
              <option value="q">quantity</option>
              <option value="1">1</option>
              <option value="2">2</option>
              <option value="3">3</option>
              <option value="4">4</option>
              <option value="5">5</option>
              <option value="6">6</option>
              <option value="7">7</option>
              <option value="8">8</option>
              <option value="9">9</option>
              <option value="10">10</option>
            </select>
  
  
            <input
              title="Add comment here"
              placeholder="Comment"
              type="text"
              className="form-input"
              value={this.state.comment}
              name="comment"
              onChange={this.onChange}
            />
  
  
  
            <button title="Adds the item to the grocery list" className="btn-submit">Submit <i className="fa fa-save"></i></button>
          </fieldset>
        </form>
      )
    }
  }
  
export default NewGrocery