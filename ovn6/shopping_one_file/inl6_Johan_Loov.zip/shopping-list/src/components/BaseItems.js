import React from "react"


class BaseItems extends React.Component {
    addAllItems = () => {
      this.props.addBaseItemsProps()
    }
    render() {
      return (
        <button title="Adds some standard groceries to the grocery list" onClick={this.addAllItems} className="btn-base"> Add Base Items </button>
      )
    }
  }
  
export default BaseItems