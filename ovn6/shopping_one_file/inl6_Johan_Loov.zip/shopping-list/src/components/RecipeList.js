import React from "react"
import Recipe from "./Recipe"

class RecipeList extends React.Component {

    state = {
      fetchedRecipeList: [],
      searchKey: ""
    };
  
  
    //Note: limited to 500 calls / month (see https://rapidapi.com/apidojo/api/tasty/)
    //create new key before handing in ovn 6!
    options = {
      method: 'GET',
      headers: {
        'X-RapidAPI-Key': 'a97a27dba4msh0406c51ffc2c3b6p1e955djsnfc510facd835',
        'X-RapidAPI-Host': 'tasty.p.rapidapi.com'
      }
    };
  
    fetchRecipeList = () => {
      if (this.state.searchKey.trim() === "") {
        alert("Must give a search string")
        return
      }
      fetch('https://tasty.p.rapidapi.com/recipes/list?from=0&size=20&tags=under_30_minutes&q=' + this.state.searchKey, this.options)
        .then(response => response.json())
        .then(response => this.setStateFromResponse(response))
        .catch(err => console.error(err));
    };
  
  
  
    setStateFromResponse = (responseAsJSON) => {
      var newArray = []
      for (var key in responseAsJSON.results) {
        if (responseAsJSON.results.hasOwnProperty(key)) {
          console.log(key)
          console.log(responseAsJSON.results[key].name)
          console.log(responseAsJSON.results[key].description)
          let obj = {
            "name": responseAsJSON.results[key].name,
            "details": responseAsJSON.results[key].description,
            "id": responseAsJSON.results[key].id
          }
          newArray.push(obj)
        }
      }
      //set array as state
      this.setState({
        fetchedRecipeList: newArray
        //groceryDB: [...this.state.groceryDB, this.baseItemsData]
      });
      //check for empty result
      if (this.state.fetchedRecipeList.length === 0) {
        alert("No recipes found for current search string!");
      }
    };
  
    onChange = e => {
      //use name ta to update right part of state
      this.setState({
        [e.target.name]: e.target.value,
      })
    }
  
    render() {
      return (
        <div className="recipeList">
          <h2 id="search-header">Search for recipes</h2>
          <button title="Search for recipes using a search string" onClick={this.fetchRecipeList} className="btn-search"> Search  <i className="fa fa-search"></i></button>
          <input type="text"
            className="searchText"
            name="searchKey"
            onChange={this.onChange}
          />
          <ol>
            {this.state.fetchedRecipeList.map(recipe => (
              <Recipe
                name={recipe.name}
                details={recipe.details}
                key={recipe.id} /*needed to get rid of warning*/
              />
            ))
            }
          </ol>
        </div>
      )
    }
  }
  
export default RecipeList
