import React from "react"
import GroceryList from "./GroceryList"
import QuoteFetcher from "./QuoteFetcher"
import NewGrocery from "./NewGrocery"
import RecipeList from "./RecipeList"
import BaseItems from "./BaseItems"
import { v4 as uuidv4 } from "uuid";


class AllGroceries extends React.Component {
  state = {
    groceryDB: [],
    baseItemsAdded: false,
    fetchedQuote: "",
    quoteAuthor: ""
    /*
    fetchedQuote: "She felt Britain should not be so dependent on coal. She was in favour of building up nuclear energy to break the dependence on coal, and the main opposition to nuclear came from the environment movement. Mrs. Thatcher thought she could trap them with the carbon emissions argument.",
    quoteAuthor: "Sune Mangs",
    */
  };

  handleChange = (id) => {
    this.setState(prevState => ({
      groceryDB: prevState.groceryDB.map(item => {
        if (item.id === id) {
          return {
            ...item,
          }
        }
        return item
      }),
    }))
  };

  delItem = id => {
    this.setState({
      groceryDB: [
        ...this.state.groceryDB.filter(item => {
          return item.id !== id;
        })
      ]
    });
  };


  printList = () => {
    console.log("Jump to print page");
    //use local storage to transer data to print page
    localStorage.setItem("groceryDB", JSON.stringify(this.state.groceryDB))
    localStorage.setItem("fetchedQuote", JSON.stringify(this.state.fetchedQuote))
    localStorage.setItem("quoteAuthor", JSON.stringify(this.state.quoteAuthor))
    window.location = "print.html"
  };

  baseItemsData =
    [
      {
        id: uuidv4(),
        item: "six-pack of beer",
        quantity: "2",
        comment: "E.g. Budweiser (max 2.8 % alc) "
      },
      {
        id: uuidv4(),
        item: "butter 600 g",
        quantity: "1",
        comment: ""
      },
      {
        id: uuidv4(),
        item: "milk 1 liter",
        quantity: "5",
        comment: "Should be lactose free"
      },
      {
        id: uuidv4(),
        item: "bread",
        quantity: "1",
        comment: "Choose a brand with less sugar"
      },
      {
        id: uuidv4(),
        item: "Cheese",
        quantity: "1",
        comment: "Cheddar or Goude"
      },
    ]

  addBaseItems = () => {
    if (this.state.baseItemsAdded) {
      alert("Base items has already been added!");
      return;
    }
    //add all items from array
    this.setState({
      //groceryDB: this.baseItemsData
      groceryDB: [...this.state.groceryDB, ...this.baseItemsData]
    });
    this.setState({
      baseItemsAdded: true
    });
  };


  addQuote = (quote, author) => {
    console.log("AAA " + author)
    this.setState({
      fetchedQuote: quote,
      quoteAuthor: author
    });
  };

  addItem = (item, quantity, comment) => {
    const newitem = {
      id: uuidv4(),
      item: item,
      quantity: quantity,
      comment: comment
    };
    this.setState({
      groceryDB: [...this.state.groceryDB, newitem]
    });
  };

  setUpdate = (updateditem, id) => {
    this.setState({
      groceryDB: this.state.groceryDB.map(item => {
        if (item.id === id) {
          item.item = updateditem
        }
        return item
      }),
    })
  }

  setUpdateQnt = (updatedItemQnt, id) => {
    this.setState({
      groceryDB: this.state.groceryDB.map(item => {
        if (item.id === id) {
          item.quantity = updatedItemQnt
        }
        return item
      }),
    })
  }

  setUpdatedComment = (updatedComment, id) => {
    this.setState({
      groceryDB: this.state.groceryDB.map(item => {
        if (item.id === id) {
          item.comment = updatedComment
        }
        return item
      }),
    })
  }

  render() {
    return (
      <div className="container">
        <div className="inner">
          <h1 className="sidTopp">The Professional Grocery Shopper Tool</h1>
          <div id="outer-container">
            <div id="grocery-container">
              <GroceryList
                groceryDB={this.state.groceryDB}
                fetchedQuote={this.state.fetchedQuote}
                quoteAuthor={this.state.quoteAuthor}
                handleChangeProps={this.handleChange}
                deleteItemProps={this.delItem}
                setUpdate={this.setUpdate}
                setUpdateQnt={this.setUpdateQnt}
                setUpdatedComment={this.setUpdatedComment}
                usedInPrintView={false}
              />
              <BaseItems addBaseItemsProps={this.addBaseItems} />
              <QuoteFetcher addQuoteProps={this.addQuote} />
              <button title="create a printable page" className="btn-print" onClick={this.printList} > Print <i className="fa fa-print"></i></button>


              <br></br><br></br><br></br>
              <NewGrocery addItemProps={this.addItem} />
            </div>
            <RecipeList />
          </div>

        </div>
      </div>
    );
  }
}

export default AllGroceries