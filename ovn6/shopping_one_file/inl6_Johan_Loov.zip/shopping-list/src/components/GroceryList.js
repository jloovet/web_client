import React from "react"
import GroceryInList from "./GroceryInList"

class GroceryList extends React.Component {
    render() {
      return (
        <div className="table-container">
          <table>
            <caption>My Grocery Shopping List:</caption>
            <tbody>
              <tr>
                <th>Name</th>
                <th>Quantity</th>
                <th>Comment</th>
              </tr>
              {this.props.groceryDB.map(item => (
                <GroceryInList
                  key={item.id}
                  item={item}
                  handleChangeProps={this.props.handleChangeProps}
                  deleteItemProps={this.props.deleteItemProps}
                  setUpdate={this.props.setUpdate}
                  setUpdateQnt={this.props.setUpdateQnt}
                  setUpdatedComment={this.props.setUpdatedComment}
                  usedInPrintView={this.props.usedInPrintView}
                />
              ))}
              <tr>
                {!this.props.usedInPrintView &&
                  <td title={"A quote by " + this.props.quoteAuthor} className="quote" colSpan="3">
                    {this.props.fetchedQuote.substring(0, 210)}</td>
                }
                {this.props.usedInPrintView &&
                  <td title={"A quote by " + this.props.quoteAuthor} className="quote" colSpan="3">
                    {this.props.fetchedQuote}
                    <br></br>
                    {"  -A quote by " + this.props.quoteAuthor}</td>
                }
              </tr>
            </tbody>
          </table>
        </div>
      )
    }
  }
  

export default GroceryList