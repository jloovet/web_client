import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';


import 'font-awesome/css/font-awesome.min.css';

import AllGroceries from "./components/AllGroceries"

const root = ReactDOM.createRoot(document.getElementById("root"))
root.render(<React.StrictMode>
    <AllGroceries />
</React.StrictMode >
);
